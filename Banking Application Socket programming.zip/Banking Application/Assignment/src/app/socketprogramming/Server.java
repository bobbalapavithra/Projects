package app.socketprogramming;

import java.net.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import javax.management.RuntimeErrorException;

import java.io.*;

public class Server {

	// initialize socket and input stream
	private Socket socket = null;
	private ServerSocket server = null;
	public static final String DB_SCHEMA_NAME = "bankingsystem";
	private static Scanner scan = new Scanner(System.in);
	static ObjectOutputStream outputStream;
	static ObjectInputStream inputStream;
	private static Connection connection;
	public static String username, password, account_type;

	private enum AllForm {
		LOGIN_SIGNUP_FORM, BANK_FUNC, USERNAME_PWD_SIGN_UP_FORM, USERNAME_PWD_SIGN_IN_FORM, EXIT
	}

	private static AllForm current_form = AllForm.LOGIN_SIGNUP_FORM;

	public Server(int port) {
		try {

			server = new ServerSocket(port);
			System.out.println("***************** Welcome to our Banking System *****************");

			System.out.println("Waiting for a client ...");

			socket = server.accept();
			System.out.println("Client accepted");

			outputStream = new ObjectOutputStream(socket.getOutputStream());
			inputStream = new ObjectInputStream(socket.getInputStream());
			while (current_form != AllForm.EXIT) {
				loginSignUpForm();

			}
			System.out.println("Closing connection");

			// close connection
			socket.close();
		} catch (IOException i) {
			System.out.println(i);
		}
	}

	private void loginSignUpForm() {
		current_form = AllForm.LOGIN_SIGNUP_FORM;
		String user_ip = input_from_client(
				"***************** Select an option *****************\n1. Sign Up\n2. Sign In\n4. Exit");
		switch (user_ip) {
			case "1":
				usernamePassForm(true);
				if (checkIfUsernameExists(username)) {
					send_msg_to_client(
							"***************** Failed: User Already Exists, Kindly Login using same username! *****************");
					loginSignUpForm();
					user_ip = "";
				} else {
					signUp(username, password, account_type);
					bankFunc();
				}
				break;
			case "2":
				usernamePassForm(false);
				if (isLoginSuccess(username, password)) {
					send_msg_to_client("\nLogin Success! Welcome " + username + "\n");
					bankFunc();
				} else {
					send_msg_to_client("Login Failed! Try Again!");
					user_ip = "";
				}
				break;
			case "4":
				current_form = AllForm.EXIT;
				send_msg_to_client("Success: Thank You for banking with us! ,Connection Closed Successfully!");
				break;
			default:
				send_msg_to_client("Invalid Input");
				break;

		}
	}

	private static void signUp(String username, String password, String account_type) {
		String query = "insert into user(username,password,account_type) values (?,?,?)";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, username);
			statement.setString(2, password);
			statement.setString(3, account_type);
			statement.execute();
			send_msg_to_client("***************** Sign Up Success *****************");

		} catch (SQLException e) {
			throw new RuntimeErrorException(null,
					"***************** Sign Up Failed *****************" + e.getMessage());
		}
	}

	private boolean checkIfUsernameExists(String username) {
		String query = "select * from user where username=?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, username);
			ResultSet rs = statement.executeQuery();
			return rs.next() ? true : false;

		} catch (SQLException e) {
			throw new RuntimeErrorException(null, "***************** Error Connecting to Database *****************");
		}
	}

	private boolean isLoginSuccess(String username, String password) {
		String query = "select * from user where username=? and password = ?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, username);
			statement.setString(2, password);
			ResultSet rs = statement.executeQuery();
			return rs.next() ? true : false;

		} catch (SQLException e) {
			throw new RuntimeErrorException(null, "***************** Error Connecting to Database *****************");
		}
	}

	public static Connection connect(String schema) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String mysql = "jdbc:mysql://localhost:3306/" + schema + "?useSSL=false";
			return DriverManager.getConnection(mysql, "root", "root");
		} catch (ClassNotFoundException | SQLException e) {
			throw new RuntimeErrorException(null, "***************** Unable to connect Database *****************");
		}
	}

	public static void main(String args[]) {
		connection = connect(DB_SCHEMA_NAME);
		if (connection == null) {
			return;
		}
		Server server = new Server(5000);
	}

	public static void usernamePassForm(boolean isSignUpForm) {
		username = input_from_client("Enter Username");
		password = input_from_client("Enter Password");
		if (isSignUpForm) {
			setAccountType();
		}
	}

	public static void setAccountType() {
		account_type = input_from_client("Enter Account Type 1.Savings 2.Loan");
		if(account_type.equals("1")){
			account_type = "Savings";
		}
		else{
			account_type = "Loan";
		}
	}

	public static String input_from_client(String msg) {
		try {
			outputStream.writeObject(msg);
			inputStream.readLine();
			return (String) inputStream.readObject();
		} catch (ClassNotFoundException | IOException e) {
			throw new RuntimeErrorException(null, "***************** Error during sending message *****************");
		}
	}

	public static void send_msg_to_client(String msg) {
		try {
			outputStream.writeObject(msg + "\n");
		} catch (IOException e) {
			throw new RuntimeErrorException(null, "***************** Error during sending message *****************");
		}
	}

	public static void bankFunc() {
		current_form = AllForm.BANK_FUNC;
		while (current_form == AllForm.BANK_FUNC) {
			String input = input_from_client(
					"***************** Select functionality for your visit *****************\n1. Withdraw\n2. Deposit\n3. Show Balance\n4. Get Statement\n5. Exit");
			switch (input) {
				case "1":
					withdraw();
					break;
				case "2":
					deposit();
					break;
				case "3":
					int bal = getBalanceGivenUsername(username);
					send_msg_to_client("Data fetch Success!\nCurrent Balance: " + bal);
					break;
				case "4":
					System.out.println("called");
					getStatement(username);
					break;
				case "5":
					current_form = AllForm.EXIT;
					send_msg_to_client(
							"***************** Success: Thank You for banking with us! ,connection closed successfully! *****************");
					break;
				default:
					send_msg_to_client("Invalid Input");
					break;
			}
		}

	}

	private static void deposit() {
		String input = input_from_client("Enter Amount to deposit");
		try {
			int amt = Integer.parseInt(input);
			if (amt < 0) {
				send_msg_to_client("Enter Amount greater than zero, Deposit Failed!");
			}
			int bal = getBalanceGivenUsername(username);
			int balance = bal + amt;
			setBalanceGivenUsername(balance, username);
			addToStatement(username, "deposit", amt, balance);

		} catch (Exception e) {
			send_msg_to_client("Invalid Input");
		}
	}

	private static void withdraw() {
		String input = input_from_client("Enter amount to withdraw");
		try {
			int amt = Integer.parseInt(input);
			if (amt < 0) {
				send_msg_to_client("Enter amount greater than zero, Withdraw Failed!");
			}
			int bal = getBalanceGivenUsername(username);
			String acc_type = getAccountTypeGivenUsername(username);
			if (bal < amt) {
				if (acc_type.equals("Loan")) {
					if ((bal-amt) >= -10000) {
						int balance = bal - amt;
						setBalanceGivenUsername(balance, username);
						addToStatement(username, "Loan", amt, balance);
					} else {
						send_msg_to_client("Current Balance is: " + bal
								+ " and your maximum limit of loan is 10000, Withdraw Failed!");
					}
				} else {
					send_msg_to_client("Current Balance is: " + bal + ", Withdraw Failed! Reason: Account type is Savings so your balance cannot be less than 0");
				}
			} else {
				int balance = bal - amt;
				setBalanceGivenUsername(balance, username);
				addToStatement(username, "withdraw", amt, balance);
			}

		} catch (Exception e) {
			send_msg_to_client("Invalid Input"+e.getMessage());
		}
	}

	private static void setBalanceGivenUsername(int bal, String username) {
		String query = "update user set amount=? where username=?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, String.valueOf(bal));
			statement.setString(2, username);
			statement.execute();
			send_msg_to_client("Balance Updated Successfully!");

		} catch (SQLException e) {
			send_msg_to_client("Error occurred! Withdraw Failed!"+e.getMessage());
			throw new RuntimeErrorException(null, "Error occurred! Withdraw Failed!" + e.getMessage());
		}
	}

	public static int getBalanceGivenUsername(String username) {
		String query = "select * from user where username=?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, username);
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				return rs.getInt(3);
			}
			throw new RuntimeErrorException(null, "Error fetching result!");
		} catch (SQLException e) {
			throw new RuntimeErrorException(null, "Error connecting to database");
		}
	}

	public static String getAccountTypeGivenUsername(String username) {
		String query = "select * from user where username=?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, username);
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				return rs.getString("account_type");
			}
			throw new RuntimeErrorException(null, "Error fetching result!");
		} catch (SQLException e) {
			throw new RuntimeErrorException(null, "Error connecting to database");
		}
	}

	private static void addToStatement(String username, String transaction_type, int amount, int balance) {
		String query = "insert into transaction(username,transaction_type,amount,balance) values (?,?,?,?)";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, username);
			statement.setString(2, transaction_type);
			statement.setInt(3, amount);
			statement.setInt(4, balance);
			statement.execute();
			send_msg_to_client("***************** Transaction Success *****************");

		} catch (SQLException e) {
			throw new RuntimeErrorException(null,
					"***************** Transaction Failed *****************" + e.getMessage());
		}
		System.out.println("Success: Work in Progress");
	}

	private static void getStatement(String username) {
		String query = "select * from transaction where username=?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, username);
			ResultSet rs = statement.executeQuery();
			if (rs.first()) {
				send_msg_to_client("-".repeat(70));
				send_msg_to_client("Bank Statement Fetched Successfully for username: " + username);
				send_msg_to_client("-".repeat(70));
				send_msg_to_client(String.format("%15s | %-15s | %-10s | %-10s",
						"Transaction ID", "Type", "Amount ($)", "Balance ($)"));
				send_msg_to_client("-".repeat(70));
				rs.absolute(0);

			} else {
				send_msg_to_client("Success: No Transactions in your Account");
			}
			while (rs.next()) {
				send_msg_to_client((String.format("%15d | %-15s | %-10d | %-10d", rs.getInt(4), rs.getString(2),
						rs.getInt(3), rs.getInt(5))));
				if (rs.isLast()) {
					send_msg_to_client("-".repeat(70));
				}
			}
		} catch (SQLException e) {
			throw new RuntimeErrorException(null, "Error connecting to database" + e.getMessage());
		}
	}

}
